close all;


TzewN = -20;
qgN = 2000;
Twew0 = 20;
Tg0 = 40;

Cpp = 1005;
ROp = 1.2;
Cpo = 2400;
ROo = 1200;

stepTime = 1000;

Tzew0 = TzewN;
qg0 = qgN * 1.0;

dqg = 0.0 * qg0;
dTzew = 0;


k=1/50;

% T=2521.5;
% T0=986.5;
T = 1762.5;
T0 = 120.1658;

Kp = 0.9*T/(k*T0);
Ti = 3.33*T0;
Ki=Kp/Ti;



Twew_zadana = Twew0;
dTwew = 3;

%%
Cvw = Cpp*ROp*60;
Cvg = Cpo*ROo*0.005;

Kcg = qg0/(Tg0-Twew0);
Kcw = qg0/(Twew0-Tzew0);

A = zeros(2);

A(1,1) = (-(Kcg+Kcw))/Cvw;
A(1,2) = Kcg/Cvw;
A(2,1) = Kcg/Cvg;
A(2,2) = (-Kcg)/Cvg;

B = zeros(2);

B(1,2) = Kcw/Cvw;
B(2,1) = 1/Cvg;


init_con = [Twew0;Tg0];

M1=[Cvw*Cvg,Cvg*(Kcg+Kcw)+Cvw*Kcg,Kcw*Kcg];
L1=Kcg;
L2=[Cvg*Kcw,Kcg*Kcw];
L3=[Cvw,Kcg+Kcw];
L4=Kcg*Kcw;
%%

f1 = figure(1);
simOut = sim('model',5000);
plot(simOut.TwewId,"LineWidth", 4);
movegui(f1,[140,300]);
title("ISA");
hold on;
plot(simOut.TwewId2,'r:',"LineWidth", 3);
title("model");


f2 = figure(2);
movegui(f2,[700,300]);
plot(simOut.TwewSt,"LineWidth", 2);
title('obiekt');


% plot(simOut.TwewId,"LineWidth", 4);
% hold on;
% plot(simOut.TwewId2,':',"LineWidth", 3);

% figure(1);
% subplot(211);
% 
% plot(out.TwewInt,'b',"LineWidth", 4);
% hold on;
% % plot(out.TwewSt,'r-.',"LineWidth", 2.5);
% % plot(out.TwewTr,'y:',"LineWidth", 2);
% plot(out.TwewId,'g--',"LineWidth", 2);
% ylabel("Twew");
% xlabel("t");
% title("");
% 
% % figure(2);
% subplot(212);
% 
% plot(out.TgInt,'b',"LineWidth", 4);
% hold on;
% plot(out.TgSt,'r-.',"LineWidth", 2.5);
% plot(out.TgTr,'y:',"LineWidth", 2);
% ylabel("Tg");
% xlabel("t");
% title("");






